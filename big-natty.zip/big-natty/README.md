# Big Natty

A Pen created on CodePen.

Original URL: [https://codepen.io/Rolland-Arkoh/pen/vEEJYxd](https://codepen.io/Rolland-Arkoh/pen/vEEJYxd).

